/*
 * Copyright (c) 2016 VMware, Inc. All Rights Reserved.
 * This software is released under MIT license.
 * The full license information can be found in LICENSE in the root directory of this project.
 */
import { Component } from "@angular/core";
import { Http, Headers, RequestOptions, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { environment } from '../../environments/environment';

@Component({
    styleUrls: ['./home.component.scss'],
    templateUrl: './home.component.html',
})
export class HomeComponent {
    exampleServices: any[];

    constructor(private http: Http) {
        this.getExmapleServices();
    }

    getExmapleServices(): void {
        // Switch between /api/core/example and /core/example depends on
        // whether the environment is development or production
        let prefix: string = environment.production ? '' : '/api';
        let url: string = prefix + '/core/examples';

        this.http.get(url)
            .map((res: Response) => {
                return res.json();
            })
            .subscribe((document: any) => {
                this.exampleServices = document.documentLinks;
            });
  }
}
